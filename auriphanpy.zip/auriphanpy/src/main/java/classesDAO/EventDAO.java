package classesDAO;

import models.Event;

public interface EventDAO extends GenericDAO<Event>{

}
