package classesDAO;

import models.EventType;

public interface EventTypeDAO extends GenericDAO<EventType>{

}
