package classesDAO;

import models.Image;

public interface ImageDAO extends GenericDAO<Image> {

}
