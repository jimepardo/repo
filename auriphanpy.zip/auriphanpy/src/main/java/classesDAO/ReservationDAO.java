package classesDAO;

import models.Reservation;

public interface ReservationDAO extends GenericDAO<Reservation>{

}
