package classesDAO;

import models.ScoreCriterion;

public interface ScoreCriterionDAO extends GenericDAO<ScoreCriterion>{

}
