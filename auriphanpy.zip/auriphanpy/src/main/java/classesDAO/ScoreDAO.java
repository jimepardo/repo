package classesDAO;

import models.Score;

public interface ScoreDAO extends GenericDAO<Score>{

}
