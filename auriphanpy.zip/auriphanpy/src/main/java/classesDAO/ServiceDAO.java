package classesDAO;

import models.Service;

public interface ServiceDAO extends GenericDAO<Service>{

}
