package classesDAO;

import models.ServiceType;

public interface ServiceTypeDAO extends GenericDAO<ServiceType>{

}
